#include <stdio.h>
int main(){
	int time;
	printf("Enter the time(0-23):");
	scanf("%d", &time);
	if (time>=5 && time<=11){
		printf("Good morning\n");
	}else if(time>=12 && time<=18){
		printf("Good evening\n");
	}else if(time>=18 && time<=24){
		printf("Good night\n");
	}else{
		printf("Invalid time");
	}
	return 0;
}