#include <stdio.h>
int main(){
	int lsvalue;
	printf("Enter light sensor value (0-1000):");
	scanf("%d" , &lsvalue);
	if (lsvalue>500){
       printf("sunshine\n");
    }else if(lsvalue>=100 && lsvalue<=500){
       printf("lightening\n");
	}else if(lsvalue>=0 && lsvalue<=100){
		printf("Evening\n");
	}else{
		printf("Invalid light sensor value");
	}
	return 0;
	}

	
	

