#include <stdio.h>
int main(){
	int temp;
	printf("Enter the value of temperature:");
	scanf("%d", &temp);
	if (temp<0){
		printf("Freezing weather\n");
	}else if(temp>=0 && temp<=10){
		printf("Very cold weather\n");
	}else if(temp>=11 && temp<=20){
		printf("Cold weather\n");
	}else if(temp>=21 && temp<=30){
		printf("Normal temperature\n");
	}else if(temp>=31 && temp<=40){
		printf("Hot weather\n");
	}else if(temp = 40){
		printf("Very hot weather\n");
	}else{
		printf("Invalid value of temperature\n");
	}
    return 0;
}