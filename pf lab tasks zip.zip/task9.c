#include <stdio.h>
int main(){
	int fscper, ntsper;
	printf("Enter your fsc percentage:");
	scanf("%d", &fscper);
	printf("Enter your nts percentage:");
	scanf("%d", &ntsper);
	if (fscper>70 && ntsper>70){
		printf("Seat allocated in oxford university IT department\n");
	}else if(fscper>70 && ntsper>60){
		printf("Seat allocated in oxford university electronics department\n");
	}else if(fscper>70 && ntsper>50){
		printf("Seat allocated in oxford university telecommunication department\n");
	}else{
		printf("You do not meet the criteria for any department in oxford university");
		return 1;
	}
    if(fscper>60 && ntsper>50){
    	printf("Seat allocated in IT department at MIT\n");
	}else if(fscper>59 && ntsper>50){
		printf("Seat allocated in chemical department at MIT\n");
	}else if(fscper>40 && fscper>50 && ntsper>50){
		printf("Seat allocated in computer department at MIT\n");
	}else{
		printf("You do not meet the criteria for any department in MIT");
	}
	return 0;
}