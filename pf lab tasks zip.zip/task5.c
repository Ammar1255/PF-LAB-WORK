#include <stdio.h>
int main(){
	int customerid;
	char customername;
	float unitconsumed, billamount ,surcharge;
	
	printf("Enter customerid:");
	scanf("%d", &customerid);
	printf("Enter customername:");
	scanf("%c", &customername);
	printf("Enter unitconsumed:");
	scanf("%f", &unitconsumed);
	
	if (unitconsumed<=199){
	   billamount= unitconsumed*16.20;
   }else if (unitconsumed>=200 && unitconsumed < 300){
		billamount= unitconsumed*20.10;
   }else if (unitconsumed>=300 && unitconsumed < 500) {
        billamount= unitconsumed*27.10;
   }else if (unitconsumed>=500){
        billamount= unitconsumed*35.90;
   }else{
   	printf("Invalid unitconsumed\n");
   	return 1;
   }
   
   if (billamount>18000) {
   surcharge=billamount*0.15;
   billamount+surcharge;
   }
   
   printf("Customerid: %d\n", customerid);
   printf("Customername: %c\n",customername);
   printf("Unitconsumed: %.2f\n", unitconsumed);
   printf("surcharge: %.2f\n", surcharge);
   printf("Total bill amount: %.2f\n", billamount);
	return 0;
}