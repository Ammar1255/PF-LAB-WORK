#include <stdio.h>

int main() {
    
    float cost, discountAmount, finalAmount;
    int discountPercentage;

    
    printf("Enter the cost of shopping: ");
    scanf("%f", &cost);

    
    if (cost < 500) {
        printf("Amount not eligible for discount.\n");
    } else {
        
        if (cost < 2000) {
            discountPercentage = 5;
        } else if (cost <= 4000) {
            discountPercentage = 10;
        } else if (cost <= 6000) {
            discountPercentage = 20;
        } else {
            discountPercentage = 35;
        }

        
        discountAmount = cost * (discountPercentage / 100.0);
        
        finalAmount = cost - discountAmount;

        
        printf("Actual Amount: %.2f\n", cost);
        printf("Saved Amount: %.2f\n", discountAmount);
        printf("Amount After Discount: %.2f\n", finalAmount);
    }

    return 0;
}
