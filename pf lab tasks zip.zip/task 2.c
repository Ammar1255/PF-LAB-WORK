#include <stdio.h>
int main(){
	char operator;
	int a, b;
	printf("Enter operator (+ or - or * or /)\n");
	scanf("%c" ,&operator);
	
	printf("Enter number1\n");
	scanf("%d" , &a);
	printf("Enter number 2\n");
	scanf("%d" ,&b);
	
	switch(operator){
		case '+' :
			printf("the sum is %d", a+b);
			break;
				
		case '-':
		    printf(" the difference is %d", a-b);
			break;
			
		case '*':
		    printf("the product is %d", a*b);
			break;
			
		case '/':
		printf(" the quotient is %d", a/b);
		break;
		
		
						
	}
	return 0;
}